#!/usr/bin/env bash

# bash
ln -s ~/.dotfiles/.bash_aliases ~/.bash_aliases
ln -s ~/.dotfiles/.bashrc       ~/.bashrc

# vim
ln -s ~/.dotfiles/.vim           ~/.vim

# git
ln -s ~/.dotfiles/.gitconfig    ~/.gitconfig

# vagrant
ln -s ~/.dotfiles/docker-compose.override.yml ~/alchemy/

GPG_TTY=$(tty)
export GPG_TTY
gpg --import ~/.wrench
rm ~/.wrench

